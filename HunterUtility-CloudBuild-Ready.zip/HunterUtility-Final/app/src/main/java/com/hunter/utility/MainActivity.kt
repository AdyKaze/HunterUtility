package com.hunter.utility

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hunter.utility.data.LocalSettings
import com.hunter.utility.data.Profile
import com.hunter.utility.data.ProfileStore
import kotlinx.coroutines.launch

private val Navy = Color(0xFF101725)
private val Panel = Color(0xFF192438)
private val Blue = Color(0xFF4B8DFF)
private val Muted = Color(0xFF9AAAC2)
private val Green = Color(0xFF43D6A0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HunterUtilityApp() }
    }
}

private enum class Page(val title: String, val icon: ImageVector) {
    Home("Dashboard", Icons.Default.Dashboard),
    Config("Configuration", Icons.Default.Tune),
    Profiles("Profiles", Icons.Default.Folder),
    Stats("Statistics", Icons.Default.Insights),
    Settings("Settings", Icons.Default.Settings)
}

@Composable
private fun HunterUtilityApp() {
    var page by remember { mutableStateOf(Page.Home) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Navy, surface = Panel,
        onBackground = Color.White, onSurface = Color.White)) {
        Row(Modifier.fillMaxSize().background(Navy)) {
            NavigationRail(containerColor = Color(0xFF0C1320), contentColor = Color.White,
                header = { Text("HU", color = Blue, fontSize = 24.sp, fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(vertical = 22.dp)) }) {
                Page.values().forEach { p ->
                    NavigationRailItem(selected = page == p, onClick = { page = p },
                        icon = { Icon(p.icon, contentDescription = p.title) },
                        label = { Text(p.title, fontSize = 10.sp) }, alwaysShowLabel = true)
                }
            }
            Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 18.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("HUNTER UTILITY", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                        Text(page.title, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    }
                    Surface(color = Color(0xFF153B35), shape = RoundedCornerShape(50)) {
                        Text("FREE • OFFLINE", color = Green,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(18.dp))
                when (page) {
                    Page.Home -> Dashboard { page = it }
                    Page.Config -> ConfigurationPage()
                    Page.Profiles -> ProfilesPage()
                    Page.Stats -> StatisticsPage()
                    Page.Settings -> SettingsPage()
                }
            }
        }
    }
}

@Composable
private fun Dashboard(go: (Page) -> Unit) {
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Card(Modifier.weight(1.2f).fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Icon(Icons.Default.VerifiedUser, tint = Green, modifier = Modifier.size(34.dp),
                        contentDescription = null)
                    Spacer(Modifier.height(12.dp))
                    Text("Application status", color = Muted, fontSize = 13.sp)
                    Text("Ready to use", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Settings are stored on this device.", color = Muted, fontSize = 12.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    Metric("Storage", "Local")
                    Metric("Internet", "Not required")
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("QUICK ACCESS", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickCard("Configuration", Icons.Default.Tune, Modifier.weight(1f)) { go(Page.Config) }
                QuickCard("Profiles", Icons.Default.Folder, Modifier.weight(1f)) { go(Page.Profiles) }
            }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickCard("Statistics", Icons.Default.Insights, Modifier.weight(1f)) { go(Page.Stats) }
                QuickCard("Settings", Icons.Default.Settings, Modifier.weight(1f)) { go(Page.Settings) }
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: String) {
    Column { Text(label, color = Muted, fontSize = 11.sp); Text(value, fontWeight = FontWeight.SemiBold) }
}

@Composable
private fun QuickCard(title: String, icon: ImageVector, modifier: Modifier = Modifier, click: () -> Unit) {
    Card(modifier.fillMaxHeight().clickable(onClick = click),
        colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Center) {
            Icon(icon, tint = Blue, modifier = Modifier.size(28.dp), contentDescription = null)
            Spacer(Modifier.height(10.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text("Open section", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ConfigurationPage() {
    var compact by remember { mutableStateOf(false) }
    var notifications by remember { mutableStateOf(true) }
    var haptics by remember { mutableStateOf(true) }
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(Modifier.weight(1f)) {
            Text("Preferences for this app", color = Muted)
            SwitchSetting("Compact layout", "Use denser spacing", compact) { compact = it }
            SwitchSetting("Notifications", "Allow app notifications", notifications) { notifications = it }
            SwitchSetting("Haptic feedback", "Vibration for supported interactions", haptics) { haptics = it }
        }
        Card(Modifier.weight(1f).fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(20.dp)) {
                Text("About configuration", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
                Text("These preferences affect Hunter Utility only. They do not modify a game or inject code into another process.",
                    color = Muted, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun SwitchSetting(title: String, detail: String, checked: Boolean, changed: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(detail, color = Muted, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = changed)
    }
}

@Composable
private fun ProfilesPage() {
    val context = LocalContext.current
    val store = remember { ProfileStore(context) }
    var profiles by remember { mutableStateOf(store.all()) }
    var name by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }

    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { it.write(store.exportJson().toByteArray()) }
                ?: error("File tidak dapat dibuat")
            notice = "Ekspor berhasil."
        }.onFailure { notice = "Ekspor gagal: ${it.message}" }
    }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) runCatching {
            val json = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: error("File tidak dapat dibaca")
            profiles = store.importJson(json)
            notice = "Impor berhasil."
        }.onFailure { notice = "Impor gagal: ${it.message}" }
    }

    Column(Modifier.fillMaxSize()) {
        Text("Profiles are stored on this device. JSON backup is optional.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Profile name") },
                singleLine = true, modifier = Modifier.width(250.dp))
            Button(onClick = {
                val n = name.trim()
                if (n.isNotEmpty() && profiles.none { it.name.equals(n, true) }) {
                    profiles = profiles + Profile(name = n)
                    store.save(profiles); name = ""; notice = "Profile created."
                } else notice = "Name is empty or already exists."
            }) { Icon(Icons.Default.Add, null); Text("Add") }
            OutlinedButton(onClick = { export.launch("hunter-profiles.json") }) {
                Icon(Icons.Default.FileUpload, null); Text("Export")
            }
            OutlinedButton(onClick = { import.launch(arrayOf("application/json", "text/*")) }) {
                Icon(Icons.Default.FileDownload, null); Text("Import")
            }
        }
        if (notice.isNotBlank()) Text(notice, color = Blue, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(profiles, key = { it.id }) { profile ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Folder, tint = Blue, contentDescription = null)
                        Text(profile.name, Modifier.weight(1f).padding(start = 10.dp), fontWeight = FontWeight.SemiBold)
                        TextButton(onClick = {
                            profiles = profiles + profile.copy(id = java.util.UUID.randomUUID().toString(),
                                name = "${profile.name} copy")
                            store.save(profiles); notice = "Profile duplicated."
                        }) { Text("Duplicate") }
                        if (profile.name != "Default") IconButton(onClick = {
                            profiles = profiles.filterNot { it.id == profile.id }
                            store.save(profiles); notice = "Profile deleted."
                        }) { Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Muted) }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatisticsPage() {
    val context = LocalContext.current
    val count = remember { ProfileStore(context).all().size }
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        listOf("Saved profiles" to count.toString(), "Server connections" to "0", "Subscription" to "None")
            .forEach { (label, value) ->
                Card(Modifier.weight(1f).fillMaxHeight(),
                    colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.Center) {
                        Text(label, color = Muted, fontSize = 12.sp)
                        Text(value, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
    }
}

@Composable
private fun SettingsPage() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { LocalSettings(context) }
    val dark by store.darkTheme.collectAsState(initial = true)
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Application settings", color = Muted)
        SwitchSetting("Dark appearance", "Dark gaming-inspired interface", dark) {
            scope.launch { store.setDarkTheme(it) }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(18.dp)) {
                Text("Hunter Utility", fontWeight = FontWeight.Bold)
                Text("Version 1.0.0 • Android 8.0+ • Landscape", color = Muted, fontSize = 12.sp)
                Text("Standalone local utility. No account or subscription.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}
