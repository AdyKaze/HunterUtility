package com.hunter.utility.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "hunter_settings")
class LocalSettings(private val context: Context) {
    private val darkKey = booleanPreferencesKey("dark_theme")
    val darkTheme = context.dataStore.data.map { it[darkKey] ?: true }
    suspend fun setDarkTheme(value: Boolean) {
        context.dataStore.edit { it[darkKey] = value }
    }
}
