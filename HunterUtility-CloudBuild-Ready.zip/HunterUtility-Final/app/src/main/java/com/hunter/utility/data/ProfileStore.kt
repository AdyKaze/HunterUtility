package com.hunter.utility.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Profile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val compactLayout: Boolean = false,
    val notifications: Boolean = true,
    val haptics: Boolean = true
)

class ProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("hunter_profiles", Context.MODE_PRIVATE)

    fun all(): List<Profile> {
        val raw = prefs.getString("profiles", null) ?: return listOf(Profile(id = "default", name = "Default"))
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Profile(o.optString("id", UUID.randomUUID().toString()),
                    o.optString("name", "Profile"), o.optBoolean("compactLayout"),
                    o.optBoolean("notifications", true), o.optBoolean("haptics", true))
            }.ifEmpty { listOf(Profile(id = "default", name = "Default")) }
        }.getOrElse { listOf(Profile(id = "default", name = "Default")) }
    }

    fun save(items: List<Profile>) {
        val a = JSONArray()
        items.forEach { p ->
            a.put(JSONObject().put("id", p.id).put("name", p.name)
                .put("compactLayout", p.compactLayout)
                .put("notifications", p.notifications).put("haptics", p.haptics))
        }
        prefs.edit().putString("profiles", a.toString(2)).apply()
    }

    fun exportJson(): String {
        val a = JSONArray()
        all().forEach { p ->
            a.put(JSONObject().put("name", p.name).put("compactLayout", p.compactLayout)
                .put("notifications", p.notifications).put("haptics", p.haptics))
        }
        return a.toString(2)
    }

    fun importJson(json: String): List<Profile> {
        val a = JSONArray(json)
        val incoming = (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val n = o.optString("name").trim()
            require(n.isNotEmpty()) { "Ada profil tanpa nama." }
            Profile(name = n, compactLayout = o.optBoolean("compactLayout"),
                notifications = o.optBoolean("notifications", true), haptics = o.optBoolean("haptics", true))
        }
        require(incoming.isNotEmpty()) { "File tidak berisi profil." }
        val merged = (all() + incoming).distinctBy { it.name.lowercase() }
        save(merged)
        return merged
    }
}
