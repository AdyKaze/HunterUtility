# Hunter Utility — panduan sederhana

## Isi aplikasi
- Dashboard dan menu navigasi.
- Pengaturan aplikasi sederhana.
- Profil yang tersimpan di perangkat.
- Tambah, hapus, dan duplikasi profil.
- Impor dan ekspor profil JSON.
- Statistik ringkas.
- Tidak ada akun, server lisensi, pembayaran, atau subscription.

## Cara membuat APK
1. Ekstrak ZIP.
2. Instal Android Studio di komputer.
3. Buka folder `HunterUtility-Final` melalui Android Studio.
4. Gunakan JDK 17 dan tunggu Gradle Sync.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Pilih **locate** pada notifikasi untuk menemukan APK.
7. Pindahkan APK ke HP dan instal.

Minimum Android 8.0 (API 26), orientasi Landscape, penyimpanan lokal.

Aplikasi ini adalah utilitas mandiri untuk konfigurasi aplikasi sendiri. Tidak ada injeksi kode, manipulasi memori game, ESP/teleport, atau pembukaan fitur berbayar aplikasi pihak lain.


## Cara membuat APK hanya dengan HP (cloud build)
1. Buat akun GitHub melalui browser di https://github.com jika belum punya.
2. Buat repository baru bernama `HunterUtility` dan pilih **Public** (agar GitHub Actions tersedia pada paket gratis dengan batas penggunaan standar).
3. Ekstrak ZIP di HP menggunakan aplikasi pengelola arsip.
4. Di halaman repository, gunakan **Add file > Upload files**, lalu unggah semua isi folder `HunterUtility-Final` (termasuk folder tersembunyi `.github`).
5. Buka tab **Actions**, pilih workflow **Build Hunter Utility APK**, lalu tekan **Run workflow**. Jika tab belum terlihat, refresh halaman setelah unggahan selesai.
6. Tunggu proses selesai dengan tanda centang hijau. Buka hasil run tersebut, cari bagian **Artifacts**, lalu unduh `Hunter-Utility-APK`.
7. Ekstrak ZIP artifact yang diunduh. File di dalamnya bernama `app-debug.apk`. Buka file itu untuk memasang aplikasi.

Catatan: unggah isi folder proyek, bukan file ZIP proyek itu sendiri. Pastikan folder `.github/workflows` ikut terunggah. Jangan pernah mengunggah kata sandi, token, atau kunci pribadi ke repository.
